
import React, { useState } from 'react';
import { AdminNotification } from '../../types';
import { DocumentDownloadIcon, EyeIcon } from '../icons/FeatureIcons'; // Re-using EyeIcon for view

interface TeacherNotificationPageProps {
  notifications: AdminNotification[];
}

const TeacherNotificationPage: React.FC<TeacherNotificationPageProps> = ({ notifications }) => {
  const [selectedNotification, setSelectedNotification] = useState<AdminNotification | null>(null);

  const handleDownloadFile = (fileUrl: string, fileName: string) => {
    if (!fileUrl) return;
    const link = document.createElement('a');
    link.href = fileUrl;
    link.download = fileName;
    link.target = "_blank";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleViewNotification = (notification: AdminNotification) => {
    setSelectedNotification(notification);
  };

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-slate-100">Notifications from Admin</h3>
      
      {notifications.length === 0 ? (
        <p className="text-slate-400 text-center py-4">No notifications available at the moment.</p>
      ) : (
        <div className="overflow-x-auto bg-slate-600 p-1 rounded-md shadow">
          <table className="min-w-full divide-y divide-slate-500">
            <thead className="bg-slate-500">
              <tr>
                <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-slate-100 sm:pl-6">Sr.No</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-slate-100">Date</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-slate-100">Notification</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-slate-100">File</th>
                <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-slate-100">Remarks</th>
                <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700">
              {notifications.map((n, index) => (
                <tr key={n.id}>
                  <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-slate-200 sm:pl-6">{index + 1}</td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-300">{new Date(n.date).toLocaleDateString()}</td>
                  <td className="px-3 py-4 text-sm text-slate-300 max-w-sm" title={n.message}>
                    <div className="font-medium text-slate-100">{n.title}</div>
                    <div className="truncate text-xs text-slate-400">{n.message}</div>
                  </td>
                  <td className="whitespace-nowrap px-3 py-4 text-sm text-slate-300">
                    {n.fileUrl ? (
                      <button 
                        onClick={() => handleDownloadFile(n.fileUrl!, n.fileName || 'document.pdf')} 
                        className="text-sky-400 hover:text-sky-300 hover:underline flex items-center text-xs"
                        title={`Download ${n.fileName || 'notification file'}`}
                      >
                        <DocumentDownloadIcon className="w-4 h-4 mr-1"/> {n.fileName}
                      </button>
                    ) : (
                      'N/A'
                    )}
                  </td>
                  <td className="px-3 py-4 text-sm text-slate-300 max-w-xs truncate" title={n.remarks}>{n.remarks || 'N/A'}</td>
                  <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-center text-sm font-medium sm:pr-6">
                    <button 
                      onClick={() => handleViewNotification(n)} 
                      className="text-sky-400 hover:text-sky-300 p-1 rounded hover:bg-sky-700/50" 
                      title="View Details"
                    >
                      <EyeIcon className="w-5 h-5" /> <span className="sr-only">View</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
       {/* Simple modal placeholder - replace with a proper modal component if needed */}
      {selectedNotification && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50" onClick={() => setSelectedNotification(null)}>
            <div className="bg-slate-700 p-6 rounded-lg shadow-xl max-w-lg w-full" onClick={e => e.stopPropagation()}>
                <h4 className="text-xl font-semibold text-sky-300 mb-3">Notification Details</h4>
                <p className="text-sm text-slate-300"><strong className="text-slate-100">Date:</strong> {new Date(selectedNotification.date).toLocaleDateString()}</p>
                <p className="text-sm text-slate-300 mt-1"><strong className="text-slate-100">Title:</strong> {selectedNotification.title}</p>
                <p className="text-sm text-slate-300 mt-1"><strong className="text-slate-100">Message:</strong> {selectedNotification.message}</p>
                <p className="text-sm text-slate-300 mt-1"><strong className="text-slate-100">File:</strong> {selectedNotification.fileName || 'N/A'}</p>
                <p className="text-sm text-slate-300 mt-1"><strong className="text-slate-100">Remarks:</strong> {selectedNotification.remarks || 'N/A'}</p>
                <div className="mt-6 flex space-x-3">
                    {selectedNotification.fileUrl && (
                        <a 
                            href={selectedNotification.fileUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="bg-sky-600 text-white py-2 px-4 rounded hover:bg-sky-700 text-sm font-medium"
                        >
                            View Attachment
                        </a>
                    )}
                    <button 
                        onClick={() => setSelectedNotification(null)} 
                        className="py-2 px-4 bg-slate-600 text-white rounded hover:bg-slate-500 text-sm font-medium"
                    >
                        Close
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default TeacherNotificationPage;
