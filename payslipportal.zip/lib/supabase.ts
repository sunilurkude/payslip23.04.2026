
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

let client: SupabaseClient | null = null;

// Using a Proxy to lazily initialize the Supabase client.
// This prevents the app from crashing on startup if the environment variables are missing.
export const supabase = new Proxy({} as SupabaseClient, {
  get: (_target, prop) => {
    if (prop === 'then') return undefined; // Handle promise checks if any
    
    if (!supabaseUrl || !supabaseAnonKey) {
      throw new Error(
        'Supabase configuration is missing. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in the Secrets panel. ' +
        'You can find these in your Supabase Project Settings > API.'
      );
    }

    if (!client) {
      client = createClient(supabaseUrl, supabaseAnonKey);
    }

    const value = (client as any)[prop];
    return typeof value === 'function' ? value.bind(client) : value;
  }
});
